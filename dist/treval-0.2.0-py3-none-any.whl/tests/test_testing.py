"""
Test del módulo de testing nativo de treval.
"""
from treval.testing import TestCaseDef, TestResult, TestRunner, TestSuite, case


def test_suite_adds_tests():
    """Una suite debe poder añadir tests."""
    suite = TestSuite(name="test")
    assert len(suite) == 0

    suite.add(TestCaseDef(name="t1", input="hola"))
    assert len(suite) == 1
    assert suite.tests[0].name == "t1"

    suite.add(TestCaseDef(name="t2", input="mundo"))
    assert len(suite) == 2


def test_decorator_adds_to_suite():
    """El decorador @case debe añadir a la suite automáticamente."""
    suite = TestSuite(name="decorated")

    @case(suite, input="hola", name="test_hola")
    def check(response):
        assert "hola" in response

    assert len(suite) == 1
    assert suite.tests[0].name == "test_hola"
    assert suite.tests[0].assertions is not None


def test_runner_no_agent():
    """Sin función de agente, el test usa expected_output."""
    runner = TestRunner()
    test = TestCaseDef(name="simple", input="pregunta",
                       expected_output="respuesta")
    result = runner.run_test(test)
    assert result.name == "simple"
    assert result.input == "pregunta"


def test_result_passed_logic():
    """Un test pasa si score >= 0.5 y no hay error de aserción."""
    r = TestResult(name="a", input="x", output="y", score=0.8,
                   assertions_passed=True)
    assert r.passed

    r.score = 0.3
    assert not r.passed  # score bajo

    r.score = 0.8
    r.assertions_passed = False
    assert not r.passed  # aserción falló


def test_result_defaults():
    """Valores por defecto de TestResult."""
    r = TestResult(name="a", input="x")
    assert r.score == 0.0
    assert r.assertions_passed
    assert not r.error
    assert not r.output