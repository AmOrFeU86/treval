"""
RED: Evaluaciones LLM-as-judge deben funcionar.
"""
from treval.eval import EvalResult, EvalStore


def test_eval_store_save_and_list():
    """Guardar y listar evaluaciones."""
    store = EvalStore()
    store.clear()

    result = EvalResult(
        span_id=1,
        evaluator_name="correctness",
        score=0.85,
        reason="Respuesta correcta",
        metadata={"span_type": "TOOL"},
    )
    store.save(result)

    results = store.list()
    assert len(results) == 1
    assert results[0]["span_id"] == 1
    assert results[0]["score"] == 0.85


def test_eval_store_stats():
    """Cálculo de estadísticas."""
    store = EvalStore()
    store.clear()

    for score in [0.9, 0.8, 0.7]:
        store.save(EvalResult(span_id=1, evaluator_name="test", score=score))

    stats = store.get_stats()
    assert stats["count"] == 3
    assert abs(stats["avg_score"] - 0.8) < 0.001


def test_eval_result_validation():
    """Los scores deben estar entre 0 y 1."""
    r = EvalResult(span_id=1, evaluator_name="test", score=0.5, reason="ok")
    assert 0.0 <= r.score <= 1.0


# ─── _parse_judge_json tests ───

def test_parse_clean_json():
    """JSON perfectamente formado."""
    from treval.eval import _parse_judge_json
    score, reason = _parse_judge_json('{"score": 0.85, "reason": "Respuesta correcta"}')
    assert abs(score - 0.85) < 0.001
    assert "correcta" in reason


def test_parse_with_markdown():
    """JSON envuelto en ```json ... ```."""
    from treval.eval import _parse_judge_json
    text = '```json\n{"score": 0.75, "reason": "Casi correcta"}\n```'
    score, reason = _parse_judge_json(text)
    assert abs(score - 0.75) < 0.001
    assert "casi" in reason.lower()


def test_parse_with_plain_backticks():
    """JSON envuelto en ``` ... ``` sin json."""
    from treval.eval import _parse_judge_json
    text = '```\n{"score": 0.9, "reason": "Excelente"}\n```'
    score, reason = _parse_judge_json(text)
    assert abs(score - 0.9) < 0.001


def test_parse_malformed_json_unterminated():
    """JSON con string sin cerrar (caso real que fallaba)."""
    from treval.eval import _parse_judge_json
    text = '{"score": 0.80, "reason": "La respuesta es correcta al explicar que'
    score, reason = _parse_judge_json(text)
    assert abs(score - 0.80) < 0.001
    # El parser extrae el reason hasta donde puede (regex captura hasta fin de línea)
    assert reason != ""


def test_parse_malformed_no_closing_brace():
    """JSON sin llave de cierre."""
    from treval.eval import _parse_judge_json
    text = '{"score": 0.65, "reason": "Aceptable'
    score, reason = _parse_judge_json(text)
    assert abs(score - 0.65) < 0.001


def test_parse_extra_text_before_json():
    """Texto extra antes del JSON."""
    from treval.eval import _parse_judge_json
    text = 'Aquí está mi evaluación:\n\n{"score": 0.70, "reason": "Buena respuesta"}'
    score, reason = _parse_judge_json(text)
    assert abs(score - 0.70) < 0.001


def test_parse_empty_text():
    """Texto vacío → fallback."""
    from treval.eval import _parse_judge_json
    score, reason = _parse_judge_json("")
    assert abs(score - 0.5) < 0.001


def test_parse_gibberish():
    """Texto sin sentido → fallback."""
    from treval.eval import _parse_judge_json
    score, reason = _parse_judge_json("hola mundo esto no es json")
    assert abs(score - 0.5) < 0.001


def test_parse_score_only():
    """Solo score numérico, sin JSON."""
    from treval.eval import _parse_judge_json
    text = 'El score es 0.88 sobre 1.0'
    score, reason = _parse_judge_json(text)
    assert abs(score - 0.88) < 0.001


def test_parse_score_out_of_range():
    """Score > 1.0 debe clampsear a 1.0."""
    from treval.eval import _parse_judge_json
    score, reason = _parse_judge_json('{"score": 1.5, "reason": "demasiado alto"}')
    assert abs(score - 1.0) < 0.001


def test_parse_negative_score():
    """Score negativo debe clampsear a 0.0."""
    from treval.eval import _parse_judge_json
    score, reason = _parse_judge_json('{"score": -0.5, "reason": "muy mal"}')
    assert abs(score - 0.0) < 0.001