"""
Tests de ejemplo para treval test run.
Ejecutar con: treval test run py/tests/test_ejemplo.py
"""
__test__ = False

from treval.testing import case, TestSuite

suite = TestSuite(name="Ejemplos")


@case(suite, input="Cuánto es 2+2?",
       criteria="La respuesta debe ser matemáticamente correcta")
def test_suma(response: str) -> None:
    assert "4" in response or "cuatro" in response


@case(suite, input="Qué clima hace en Madrid?",
       expected_output="Madrid",
       criteria="La respuesta debe mencionar el clima de Madrid")
def test_madrid(response: str) -> None:
    assert "Madrid" in response


@case(suite, input="Saluda por favor",
       criteria="La respuesta debe ser amable y saludar")
def test_saludo(response: str) -> None:
    assert "hola" in response.lower() or "buenas" in response.lower() or "saludos" in response.lower()