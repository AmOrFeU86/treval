"""
Test del módulo de replay interactivo.
"""
from treval.db import SpanStore
from treval.replay import ReplaySession


def test_replay_session_creates():
    """Crear un ReplaySession desde un span existente."""
    store = SpanStore()
    store.clear()
    sid = store.save(name="test_tool", type="TOOL", input="hola", output="mundo")

    session = ReplaySession(sid)
    assert session.span_id == sid
    assert session.span_type == "TOOL"
    assert session.span_name == "test_tool"
    assert session.original["input"] == "hola"
    assert session.is_replayable


def test_replay_not_replayable_without_input():
    """Span sin input no es replayable."""
    store = SpanStore()
    store.clear()
    sid = store.save(name="no_input", type="AGENT")

    session = ReplaySession(sid)
    assert not session.is_replayable


def test_replay_set_input():
    """Modificar input antes de replay."""
    store = SpanStore()
    store.clear()
    sid = store.save(name="t", type="TOOL", input="original")

    session = ReplaySession(sid)
    assert session.modified_input == "original"

    session.set_input("nuevo input")
    assert session.modified_input == "nuevo input"


def test_replay_set_model():
    """Cambiar modelo."""
    store = SpanStore()
    store.clear()
    sid = store.save(name="t", type="TOOL", input="test")

    session = ReplaySession(sid)
    assert session.modified_model is None

    session.set_model("gpt-4")
    assert session.modified_model == "gpt-4"


def test_replay_no_api_key_uses_env():
    """Sin API key, replay usa la variable de entorno y funciona si está configurada."""
    import os
    store = SpanStore()
    store.clear()
    sid = store.save(name="t", type="TOOL", input="test",
                     output="result")

    session = ReplaySession(sid)
    # Con api_key vacío, intentará leer de la env
    # Esto es un test de integración, solo verificamos que no crashea
    result = session.replay(api_key="")
    assert isinstance(result, dict)
    # Si la env está configurada, debe contener output
    # Si no, debe tener error
    if not os.environ.get("OPENROUTER_API_KEY"):
        assert "error" in result