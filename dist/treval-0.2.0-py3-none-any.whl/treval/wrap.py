"""
wrap(client): envuelve un cliente OpenAI/Anthropic existente para trazar sus llamadas.

Alternativa a treval.instrument() cuando quieres control explícito.

Uso:
    client = OpenAI(api_key="...")
    client = treval.wrap(client)
    response = client.chat.completions.create(...)  # ← trazado automáticamente
"""
from __future__ import annotations

import functools
import time

from treval.db import SpanStore


def wrap(client):
    """Envuelve un cliente OpenAI para trazar todas las llamadas a completions.

    Args:
        client: Instancia de openai.OpenAI (o cualquier cliente con
                chat.completions.create)

    Returns:
        El mismo cliente con el método create parcheado.
    """
    original_create = client.chat.completions.create

    @functools.wraps(original_create)
    def traced_create(*args, **kwargs):
        store = SpanStore()
        start = time.perf_counter()
        status = "ok"
        output = None

        model = kwargs.get("model", "unknown")
        messages = kwargs.get("messages", [])
        input_text = _summarize(messages)

        try:
            result = original_create(*args, **kwargs)
            output = _extract_response(result)
            return result
        except BaseException as e:
            status = "error"
            output = f"{type(e).__name__}: {e}"
            raise
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            store.save(
                name=f"llm.{model}",
                type="LLM",
                status=status,
                input=input_text,
                output=output,
                duration_ms=duration_ms,
            )

    client.chat.completions.create = traced_create
    return client


def wrap_anthropic(client):
    """Envuelve un cliente Anthropic para trazar llamadas a messages.create()."""
    original_create = client.messages.create

    @functools.wraps(original_create)
    def traced_create(*args, **kwargs):
        store = SpanStore()
        start = time.perf_counter()
        status = "ok"
        output = None

        model = kwargs.get("model", "unknown")
        messages = kwargs.get("messages", [])
        input_text = _summarize(messages)

        try:
            result = original_create(*args, **kwargs)
            # Anthropic response tiene .content como lista de bloques
            if hasattr(result, "content"):
                output = " ".join(
                    b.text if hasattr(b, "text") else str(b)
                    for b in result.content
                )
            else:
                output = str(result)
            return result
        except BaseException as e:
            status = "error"
            output = f"{type(e).__name__}: {e}"
            raise
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            store.save(
                name=f"llm.{model}",
                type="LLM",
                status=status,
                input=input_text,
                output=output,
                duration_ms=duration_ms,
            )

    client.messages.create = traced_create
    return client


def _summarize(messages: list) -> str:
    """Convierte mensajes a string legible."""
    parts = []
    for m in (messages or []):
        role = m.get("role", "?")
        content = m.get("content", "")
        if isinstance(content, str):
            parts.append(f"{role}: {content[:200]}")
        else:
            parts.append(f"{role}: <complex content>")
    return "\n".join(parts)


def _extract_response(response) -> str:
    """Extrae texto del primer choice de una respuesta OpenAI."""
    try:
        return response.choices[0].message.content or ""
    except (AttributeError, IndexError, TypeError):
        return str(response)