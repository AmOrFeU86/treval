"""
Testing nativo para treval.

Permite definir tests para agentes y ejecutarlos con:
    treval test run tests/test_mi_agente.py

Formato de archivo de test:
    from treval.testing import case, TestSuite

    suite = TestSuite(name="MiSuite")

    @case(suite, input="qué clima hace en Madrid?",
               expected_output="Madrid",
               criteria="La respuesta debe mencionar el clima de Madrid")
    def test_madrid(response: str) -> None:
        assert "Madrid" in response
        assert "28" in response or "soleado" in response

    @test_case(suite, input="cuánto es 2+2?",
               criteria="La respuesta debe ser correcta matemáticamente")
    def test_math(response: str) -> None:
        assert "4" in response or "cuatro" in response
"""

from __future__ import annotations

import importlib.util
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

# Evitar que pytest recoja funciones de este módulo como tests
__test__ = False

from treval.eval import EvalResult, EvalStore, LLMEvaluator


@dataclass
class TestCaseDef:
    """Definición de un caso de test."""
    name: str
    input: str
    criteria: str = "correctness"
    expected_output: str = ""
    assertions: Callable[[str], None] | None = None


@dataclass
class TestResult:
    """Resultado de ejecutar un caso de test."""
    name: str
    input: str
    output: str = ""
    score: float = 0.0
    reason: str = ""
    assertions_passed: bool = True
    error: str = ""
    duration_ms: float = 0.0

    @property
    def passed(self) -> bool:
        return self.assertions_passed and self.score >= 0.5


class TestRunner:
    """Ejecuta una suite de tests y evalúa los resultados."""

    def __init__(self, agent_fn: Callable[[str], str] | None = None,
                 evaluator: LLMEvaluator | None = None):
        self.agent_fn = agent_fn
        self.evaluator = evaluator or LLMEvaluator(
            name="test",
            criteria="correctness",
        )

    def run_test(self, test: TestCaseDef) -> TestResult:
        """Ejecuta un caso de test y devuelve el resultado."""
        start = time.perf_counter()
        result = TestResult(name=test.name, input=test.input)

        try:
            # 1. Ejecutar el agente (si hay función)
            if self.agent_fn:
                output = self.agent_fn(test.input)
                result.output = output
            else:
                output = test.expected_output or ""

            # 2. Evaluación LLM
            eval_result = self.evaluator._llm_judge(
                criteria=test.criteria,
                input_text=test.input,
                output_text=output,
            )
            result.score, result.reason = eval_result

            # 3. Ejecutar aserciones (si hay)
            if test.assertions and output:
                try:
                    test.assertions(output)
                    result.assertions_passed = True
                except AssertionError as e:
                    result.assertions_passed = False
                    result.error = str(e)

        except Exception as e:
            result.error = f"Error ejecutando test: {e}"
            result.assertions_passed = False

        result.duration_ms = (time.perf_counter() - start) * 1000
        return result

    def run_suite(self, suite: TestSuite) -> list[TestResult]:
        """Ejecuta todos los tests de una suite."""
        results = []
        for test in suite.tests:
            r = self.run_test(test)
            results.append(r)
        return results


class TestSuite:
    """Colección de casos de test."""

    def __init__(self, name: str = "default"):
        self.name = name
        self.tests: list[TestCaseDef] = []

    def add(self, test: TestCaseDef) -> None:
        """Añade un caso de test a la suite."""
        self.tests.append(test)

    def __len__(self) -> int:
        return len(self.tests)


def case(suite: TestSuite, input: str,
              name: str | None = None,
              criteria: str = "correctness",
              expected_output: str = ""):
    """Decorador para definir un caso de test en una suite.

    Uso:
        @test_case(suite, input="hola", criteria="helpfulness")
        def test_algo(response: str) -> None:
            assert "hola" in response
    """
    def decorator(func):
        case = TestCaseDef(
            name=name or func.__name__,
            input=input,
            criteria=criteria,
            expected_output=expected_output,
            assertions=func,
        )
        suite.add(case)
        return func
    return decorator


def load_test_file(path: str) -> TestSuite | None:
    """Carga un archivo .py de test y devuelve la TestSuite definida en él.

    El archivo debe definir una variable 'suite' de tipo TestSuite.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Archivo de test no encontrado: {path}")

    spec = importlib.util.spec_from_file_location(path.stem, path)
    if not spec or not spec.loader:
        raise ImportError(f"No se pudo cargar: {path}")

    mod = importlib.util.module_from_spec(spec)
    # Añadir el directorio del test al path para imports relativos
    sys.path.insert(0, str(path.parent))
    try:
        spec.loader.exec_module(mod)
    finally:
        sys.path.pop(0)

    suite = getattr(mod, "suite", None)
    if suite is None:
        raise ValueError(
            f"El archivo {path} debe definir una variable 'suite' de tipo TestSuite"
        )
    return suite