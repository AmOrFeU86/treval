"""Contexto thread-local para jerarquía de spans.

Mantiene una pila de span_ids para establecer
la relación padre-hijo entre spans.
"""

import threading

_local = threading.local()


def current_span_id() -> int | None:
    """ID del span activo en este momento, o None."""
    stack = getattr(_local, "span_stack", None)
    return stack[-1] if stack else None


def push_span(span_id: int) -> None:
    """Añade un span_id a la pila (nuevo padre activo)."""
    if not hasattr(_local, "span_stack"):
        _local.span_stack = []
    _local.span_stack.append(span_id)


def pop_span() -> int | None:
    """Saca el span_id actual de la pila."""
    stack = getattr(_local, "span_stack", None)
    return stack.pop() if stack else None