"""CLI de treval: ver, filtrar y explorar spans desde la terminal."""

import argparse
import sys
from pathlib import Path
from datetime import datetime

from rich.console import Console
from rich.table import Table
from rich.text import Text

from treval.db import SpanStore
from treval.eval import EvalStore, LLMEvaluator, CORRECTNESS_EVALUATOR
from treval.otel import OtelExporter
from treval.testing import TestRunner, load_test_file
from treval.replay import ReplaySession, interactive_replay
from treval.wrap import wrap
from treval.dashboard import serve as dashboard_serve
from treval.dashboard import HTML_TEMPLATE as dashboard_html

console = Console()


def cmd_spans(args):
    """Lista los spans más recientes en una tabla."""
    store = SpanStore()
    span_type = args.type
    limit = args.limit

    spans = store.list_spans(limit=limit, type=span_type)

    if not spans:
        console.print("[dim]No hay spans registrados.[/dim]")
        return

    table = Table(title=f"Spans recientes{' (' + span_type + ')' if span_type else ''}")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Tipo", style="magenta")
    table.add_column("Nombre")
    table.add_column("Estado", no_wrap=True)
    table.add_column("Duración", justify="right")
    table.add_column("Padre", style="dim")
    table.add_column("Inicio")

    for s in spans:
        status_style = "green" if s["status"] == "ok" else "red bold"
        duration = f"{s['duration_ms']:.1f}ms" if s["duration_ms"] is not None else "-"
        parent = str(s["parent_id"]) if s["parent_id"] else "—"
        created = s["created_at"][:19] if s["created_at"] else "-"

        table.add_row(
            str(s["id"]),
            s["type"],
            s["name"],
            Text(s["status"], style=status_style),
            duration,
            parent,
            created,
        )

    console.print(table)
    console.print(f"\n[dim]{len(spans)} spans • {store.count()} total[/dim]")


def cmd_span_detail(args):
    """Muestra el detalle de un span específico + sus hijos."""
    store = SpanStore()
    span = store.get(args.span_id)
    if not span:
        console.print(f"[red]Span {args.span_id} no encontrado.[/red]")
        return

    console.print(f"\n[bold cyan]Span #{span['id']}[/bold cyan]")
    console.print(f"  [bold]Nombre:[/bold]    {span['name']}")
    console.print(f"  [bold]Tipo:[/bold]      {span['type']}")
    console.print(f"  [bold]Estado:[/bold]    ", end="")
    if span["status"] == "ok":
        console.print("[green]ok[/green]")
    else:
        console.print(f"[red bold]{span['status']}[/red bold]")
    console.print(f"  [bold]Duración:[/bold]  {span['duration_ms']:.1f}ms" if span["duration_ms"] else "")
    console.print(f"  [bold]Padre:[/bold]     {span['parent_id'] or '—'}")
    console.print(f"  [bold]Inicio:[/bold]    {span['created_at']}")

    if span["input"]:
        console.print(f"\n  [bold]Input:[/bold]")
        console.print(f"    [dim]{span['input']}[/dim]")

    if span["output"]:
        console.print(f"\n  [bold]Output:[/bold]")
        console.print(f"    [dim]{span['output']}[/dim]")

    # Hijos
    children = store.get_children(args.span_id)
    if children:
        console.print(f"\n  [bold]Hijos ({len(children)}):[/bold]")
        for c in children:
            console.print(f"    #{c['id']} {c['type']} [bold]{c['name']}[/bold] [{c['status']}]"
                          f" ({c['duration_ms']:.1f}ms)" if c['duration_ms'] else "")


def cmd_count(args):
    """Muestra el número total de spans."""
    store = SpanStore()
    console.print(f"Total spans: [bold]{store.count()}[/bold]")


def cmd_clear(args):
    """Limpia todos los spans."""
    confirm = input("¿Borrar todos los spans? (s/N): ")
    if confirm.lower() == "s":
        store = SpanStore()
        store.clear()
        console.print("[green]Spans borrados.[/green]")
    else:
        console.print("[dim]Cancelado.[/dim]")


def cmd_eval(args):
    """Evalúa spans con LLM-as-judge."""
    store = SpanStore()
    eval_store = EvalStore()
    spans = store.list_spans(limit=args.limit, type=args.type)

    if not spans:
        console.print("[dim]No hay spans para evaluar.[/dim]")
        return

    # Elegir evaluador según criterio
    criteria_map = {
        "correctness": "La respuesta es correcta, precisa y factual",
        "conciseness": "La respuesta es concisa sin información irrelevante",
        "helpfulness": "La respuesta es útil y accionable",
        "groundedness": "La respuesta usa las herramientas correctamente",
    }
    criteria = criteria_map.get(args.criteria, args.criteria)
    evaluator = LLMEvaluator(name=args.criteria, criteria=criteria)

    console.print(f"[bold]Evaluando {len(spans)} spans con criterio:[/bold] {args.criteria}")
    console.print(f"[dim]Modelo: {evaluator.model}[/dim]\n")

    results = evaluator.evaluate(spans)
    for r in results:
        eval_store.save(r)

    # Mostrar resultados
    table = Table(title="Resultados de evaluación")
    table.add_column("Span ID", style="cyan")
    table.add_column("Tipo")
    table.add_column("Score", justify="right")
    table.add_column("Razón")

    for r in results:
        score_color = "green" if r.score >= 0.7 else ("yellow" if r.score >= 0.4 else "red")
        table.add_row(
            str(r.span_id),
            r.metadata.get("span_type", ""),
            f"[{score_color}]{r.score:.2f}[/{score_color}]",
            r.reason[:80],
        )

    console.print(table)
    stats = eval_store.get_stats()
    console.print(f"\n[dim]{len(results)} evaluaciones • Media: {stats['avg_score']:.2f}[/dim]")


def cmd_evals(args):
    """Lista resultados de evaluaciones."""
    eval_store = EvalStore()
    results = eval_store.list(limit=20)

    if not results:
        console.print("[dim]No hay evaluaciones.[/dim]")
        return

    table = Table(title="Evaluaciones recientes")
    table.add_column("ID", style="cyan")
    table.add_column("Span", style="yellow")
    table.add_column("Evaluador")
    table.add_column("Score", justify="right")
    table.add_column("Razón")

    for r in results:
        score_color = "green" if r["score"] >= 0.7 else ("yellow" if r["score"] >= 0.4 else "red")
        table.add_row(
            str(r["id"]),
            f"#{r['span_id']} {(r.get('span_name') or '')[:30]}",
            r.get("evaluator_name", ""),
            f"[{score_color}]{r['score']:.2f}[/{score_color}]",
            (r.get("reason", "") or "")[:60],
        )

    console.print(table)
    stats = eval_store.get_stats()
    console.print(f"[dim]Total: {stats['count']} • Media: {stats['avg_score']:.2f}[/dim]")

def cmd_export(args):
    """Exporta spans a formato OTEL."""
    exporter = OtelExporter(
        endpoint=args.endpoint,
        use_console=args.console,
    )
    count = exporter.export_all(limit=args.limit)
    if args.console:
        console.print(f"[green]Exportados {count} spans a consola OTEL.[/green]")
    else:
        console.print(f"[green]Exportados {count} spans a {exporter.endpoint}[/green]")


def cmd_test_run(args):
    """Ejecuta tests definidos en un archivo .py."""
    try:
        suite = load_test_file(args.file)
    except (FileNotFoundError, ImportError, ValueError) as e:
        console.print(f"[red]Error cargando test:[/red] {e}")
        return

    evaluator = LLMEvaluator(
        name="test",
        criteria="correctness",
    )
    runner = TestRunner(evaluator=evaluator)

    console.print(f"[bold]Ejecutando suite:[/bold] {suite.name}")
    console.print(f"[dim]{len(suite.tests)} tests[/dim]\n")

    results = runner.run_suite(suite)
    passed = sum(1 for r in results if r.passed)
    failed = sum(1 for r in results if not r.passed)

    for r in results:
        status = "[green]✅ PASÓ[/green]" if r.passed else "[red]❌ FALLÓ[/red]"
        score_color = "green" if r.score >= 0.7 else "yellow" if r.score >= 0.4 else "red"
        console.print(f"{status} [bold]{r.name}[/bold]")
        console.print(f"   Input: [dim]{r.input[:80]}[/dim]")
        console.print(f"   Score: [{score_color}]{r.score:.2f}[/{score_color}] — {r.reason[:80]}")
        if r.error:
            console.print(f"   [red]Error: {r.error}[/red]")
        console.print()

    console.print(f"[bold]Resultado: {passed}/{len(results)} tests pasaron[/bold]")


def cmd_replay(args):
    """Re-ejecuta un span con posibilidad de modificar parámetros."""
    from treval.replay import ReplaySession
    try:
        session = ReplaySession(args.span_id)
    except ValueError as e:
        console.print(f"[red]❌ {e}[/red]")
        return

    console.print(f"[bold]🔄 Replay — #{args.span_id}[/bold] {session.span_type}: {session.span_name}")
    console.print(f"  Input original: [dim]{session.original.get('input', '')[:120]}[/dim]")

    if not session.is_replayable:
        console.print("[red]Este span no tiene input para modificar.[/red]")
        return

    if args.input:
        session.set_input(args.input)
    if args.model:
        session.set_model(args.model)
    if args.temperature is not None:
        session.set_temperature(args.temperature)

    console.print(f"  Usando modelo: [bold]{session.modified_model or session._extract_model()}[/bold]")
    console.print()

    import os
    api_key = os.environ.get("OPENROUTER_API_KEY", "")
    result = session.replay(api_key)

    if "error" in result:
        console.print(f"[red]❌ {result['error']}[/red]")
        return

    console.print(f"[green]✅ Replay completado en {result['duration_ms']:.1f}ms[/green]")

    from rich.table import Table
    table = Table(title="Comparación")
    table.add_column("", style="bold")
    table.add_column("Original", style="dim")
    table.add_column("Replay")

    orig_out = (result.get("original_output", "") or "")[:200]
    new_out = (result.get("output", "") or "")[:200]
    orig_ms = f"{result.get('original_duration_ms', 0):.1f}ms"
    new_ms = f"{result.get('duration_ms', 0):.1f}ms"

    table.add_row("Output", orig_out, new_out)
    table.add_row("Duración", orig_ms, new_ms)

    usage = result.get("usage", {})
    if usage:
        table.add_row("Tokens",
                      "-",
                      f"P:{usage.get('prompt_tokens', '-')} C:{usage.get('completion_tokens', '-')} T:{usage.get('total_tokens', '-')}")

    console.print(table)


def cmd_gateway(args):
    """Arranca el proxy gateway para interceptar tráfico LLM."""
    from treval.gateway import run_gateway
    run_gateway(host=args.host, port=args.port, upstream=args.upstream)


def cmd_dashboard(args):
    """Arranca el dashboard web local o exporta a HTML."""
    if args.export:
        import json
        from treval.db import SpanStore
        store = SpanStore()
        spans = store.list_spans(limit=2000)
        total = store.count()
        stats = {
            "totales": total,
            "AGENT": sum(1 for s in spans if s["type"] == "AGENT"),
            "OPERATION": sum(1 for s in spans if s["type"] == "OPERATION"),
            "TOOL": sum(1 for s in spans if s["type"] == "TOOL"),
            "LLM": sum(1 for s in spans if s["type"] == "LLM"),
            "errores": sum(1 for s in spans if s["status"] == "error"),
        }
        data = json.dumps({"spans": spans, "stats": stats}, default=str)
        html = dashboard_html.replace("__DATA__", data)
        Path(args.export).write_text(html, encoding="utf-8")
        console.print(f"[green]✅ Dashboard exportado a {args.export}[/green]")
        console.print(f"   {len(spans)} spans · {total} total")
        return
    dashboard_serve(port=args.port, open_browser=not args.no_open)


def cmd_metrics(args):
    """Muestra métricas agregadas de los spans."""
    store = SpanStore()
    total = store.count()
    spans = store.list_spans(limit=1000)

    if not spans:
        console.print("[dim]No hay spans para mostrar métricas.[/dim]")
        return

    # Stats por tipo
    from collections import Counter, defaultdict
    types = Counter(s["type"] for s in spans)
    statuses = Counter(s["status"] for s in spans)

    durations = defaultdict(list)
    for s in spans:
        if s.get("duration_ms") is not None:
            durations[s["type"]].append(s["duration_ms"])

    # Tabla principal
    t1 = Table(title="Resumen de spans")
    t1.add_column("Métrica", style="bold")
    t1.add_column("Valor")
    t1.add_row("Total spans", str(total))
    t1.add_row("Con errores", f"[red]{statuses.get('error', 0)}[/red]")
    t1.add_row("OK", f"[green]{statuses.get('ok', 0)}[/green]")
    console.print(t1)

    # Tabla por tipo
    t2 = Table(title="Métricas por tipo")
    t2.add_column("Tipo", style="bold")
    t2.add_column("Cantidad")
    t2.add_column("Duración media", justify="right")
    t2.add_column("Duración max", justify="right")
    t2.add_column("Tasa error", justify="right")

    for span_type in ["AGENT", "OPERATION", "LLM", "TOOL"]:
        count = types.get(span_type, 0)
        if count == 0:
            continue
        avg_d = sum(durations.get(span_type, [])) / len(durations.get(span_type, [])) if durations.get(span_type) else 0
        max_d = max(durations.get(span_type, [0])) if durations.get(span_type) else 0
        err_rate = sum(1 for s in spans if s["type"] == span_type and s["status"] == "error") / count * 100

        t2.add_row(
            span_type,
            str(count),
            f"{avg_d:.0f}ms" if avg_d else "-",
            f"{max_d:.0f}ms" if max_d else "-",
            f"[red]{err_rate:.0f}%[/red]" if err_rate > 0 else "[green]0%[/green]",
        )

    console.print(t2)


def cmd_compare(args):
    """Compara N modelos sobre el mismo prompt, cada uno M veces, con stats y costes."""
    import os
    from treval.compare import compare_models, build_report_html, MODEL_PRICES
    from rich.table import Table

    api_key = os.environ.get("OPENROUTER_API_KEY", "")
    if not api_key:
        console.print("[red]❌ OPENROUTER_API_KEY no configurada[/red]")
        console.print("   Exportala: export OPENROUTER_API_KEY=sk-...")
        return

    # Determinar modo: prompt directo o agente
    if args.agent:
        from treval.compare import compare_agents
        agent_cmd = args.agent

        console.print(f"\n[bold]🧪 Modo agente:[/bold] {agent_cmd}")
        console.print(f"   Ejecutando {agent_cmd} × {args.runs} veces")
        console.print()

        if not args.prompt:
            args.prompt = agent_cmd  # Usar el comando como prompt para evaluar

        with console.status("[bold green]Ejecutando agente...") as status:
            results = compare_agents(
                agent_cmd=agent_cmd,
                runs=args.runs,
                criteria=args.criteria,
                api_key=api_key,
            )
        prompt = agent_cmd
    else:
        prompt = args.prompt

    if not prompt:
        console.print("[red]❌ Necesitas --prompt o --agent[/red]")
        return

    models = [m.strip() for m in args.models.split(",") if m.strip()]
    if not models:
        console.print("[red]❌ No hay modelos especificados[/red]")
        return

    if len(models) < 2:
        console.print("[yellow]⚠️ Solo 1 modelo. La comparación necesita al menos 2.[/yellow]")

    console.print(f"\n[bold]📊 Comparando {len(models)} modelo(s) × {args.runs} ejecución(es)[/bold]")
    console.print(f"   Prompt: [dim]{prompt[:120]}[/dim]")
    console.print(f"   Criterio: {args.criteria}")
    console.print(f"   Modelos: {', '.join(models)}")
    console.print()

    # Verificar precios via API
    with console.status("[dim]Obteniendo precios de OpenRouter API...") as status:
        from treval.compare import get_model_price, list_available_models
        unknown = []
        for m in models:
            inp, out = get_model_price(m, api_key)
            source = "api"  # No podemos saber fuente exacta fácilmente aquí
            if inp == 5.0 and out == 15.0 and m not in getattr(list_available_models(api_key), "ids", []):
                unknown.append(m)
        if unknown:
            console.print(f"[dim]⚠️ {len(unknown)} modelo(s) sin precio conocido (se usará tarifa conservadora)[/dim]")

    with console.status("[bold green]Ejecutando comparación...") as status:
        results = compare_models(
            prompt=prompt,
            models=models,
            runs=args.runs,
            criteria=args.criteria,
            api_key=api_key,
        )

    # Mostrar resultados
    best = max(results, key=lambda r: r.mean_score) if results else None

    if best:
        console.print(f"\n[bold green]🏆 Ganador: {best.model}[/bold green] "
                      f"([green]{best.mean_score:.3f}[/green] ± {best.std_score:.3f})")

    table = Table(title="Comparación de modelos", header_style="bold")
    table.add_column("#", style="dim")
    table.add_column("Modelo")
    table.add_column("Score", justify="right")
    table.add_column("±σ", justify="right")
    table.add_column("Duración", justify="right")
    table.add_column("Coste/ejec", justify="right")
    table.add_column("Tokens", justify="right")
    table.add_column("Runs", justify="right")

    for i, r in enumerate(results):
        is_winner = r.model == (best.model if best else None) and r.mean_score == (best.mean_score if best else 0)
        style = "bold green" if is_winner else ""
        score_str = f"{r.mean_score:.3f}"
        std_str = f"{r.std_score:.3f}" if r.run_count > 1 else "—"
        dur_str = f"{r.mean_duration:.0f}ms" if r.run_count > 0 else "—"
        from treval.compare import format_cost
        cost_str = format_cost(r.mean_cost) if r.run_count > 0 else "—"
        tokens_str = f"{r.total_tokens}" if r.run_count > 0 else "—"

        table.add_row(
            str(i + 1),
            f"{'🏆 ' if is_winner else ''}{r.model}",
            score_str, std_str, dur_str, cost_str, tokens_str,
            str(r.run_count),
            style=style,
        )

    console.print(table)

    # Resumen
    if results:
        total_cost = sum(r.total_cost for r in results)
        total_runs = sum(r.run_count for r in results)
        from treval.compare import format_cost
        console.print(f"\n[dim]Total: {total_runs} ejecuciones · Coste total: {format_cost(total_cost)}[/dim]")

    # Exportar a HTML
    if args.export:
        path = args.export
        with console.status("[yellow]Generando reporte HTML..."):
            html = build_report_html(results, prompt, args.criteria)
        import os as _os
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        abs_path = _os.path.abspath(path)
        file_size = _os.path.getsize(abs_path)
        console.print(f"[green]✅ Reporte exportado a {abs_path}[/green]")
        console.print(f"   {file_size:,} bytes · {len(results)} modelo(s) · {total_runs} ejecución(es)")
        console.print(f"   Abre con: file://{abs_path}")


def cmd_init(args):
    """Crea un proyecto agente con treval preconfigurado."""
    from pathlib import Path
    import shutil

    target = Path(args.path).expanduser().resolve()
    templates_dir = Path(__file__).parent / "templates"

    if target.exists() and any(target.iterdir()):
        console.print(f"[red]❌ {target} ya existe y no está vacío[/red]")
        return

    target.mkdir(parents=True, exist_ok=True)

    # Copiar templates
    files = {
        "agent.py": "src/agent.py",
        "test_agent.py": "tests/test_agent.py",
    }
    for src_name, dest_rel in files.items():
        src = templates_dir / src_name
        if src.exists():
            dest = target / dest_rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
            console.print(f"  [green]✅[/green] {dest_rel}")

    # Crear .env
    env_path = target / ".env"
    if not env_path.exists():
        env_path.write_text("# Treval - Configuracion de API\n")
        env_path.write_text("# Obten tu API key en https://openrouter.ai/keys\n")
        env_path.write_text("OPENROUTER_API_KEY=sk-or-v1-\n")
        console.print(f"  [green]✅[/green] .env (editalo con tu API key)")

    # Crear README.md del proyecto
    readme = target / "README.md"
    if not readme.exists():
        readme.write_text("""# Mi agente con treval

Proyecto generado con `treval init`.

## Uso

```bash
python src/agent.py "tu pregunta"
```

## Ver trazas

```bash
treval spans
treval eval
treval dashboard --export dashboard.html
```

## Tests

```bash
treval test run tests/test_agent.py
```
""")
    console.print(f"\n[bold green]🎉 Proyecto creado en {target}[/bold green]")
    console.print(f"\n   [bold]Pasos siguientes:[/bold]")
    console.print(f"   1. Edita [bold].env[/bold] con tu OPENROUTER_API_KEY")
    console.print(f"   2. [bold]cd {target}[/bold]")
    console.print(f"   3. [bold]python src/agent.py[/bold]")
    console.print(f"   4. [bold]treval spans[/bold] para ver las trazas")
    console.print(f"   5. [bold]treval test run tests/test_agent.py[/bold]")


def cmd_prices(args):
    """Muestra precios de modelos desde OpenRouter API."""
    from treval.compare import list_available_models, format_cost
    from rich.table import Table
    from rich.text import Text

    api_key = os.environ.get("OPENROUTER_API_KEY", "")

    with console.status("[dim]Obteniendo precios de OpenRouter API...") as status:
        models = list_available_models(api_key)

    if not models:
        console.print("[red]❌ No se pudieron obtener precios. Sin conexión a API y sin fallback disponible.[/red]")
        return

    # Filtrar por búsqueda si se proporciona
    if args.search:
        query = args.search.lower()
        models = [m for m in models if query in m["id"].lower()]

    source_label = "OpenRouter API" if models and models[0]["source"] == "api" else "fallback local"

    table = Table(
        title=f"Precios de modelos ({source_label})",
        header_style="bold",
        show_lines=True,
    )
    table.add_column("Modelo", style="cyan")
    table.add_column("Input", justify="right")
    table.add_column("Output", justify="right")

    for m in models:
        inp_str = format_cost(m["input_price"] / 1_000_000) + "/tok"
        out_str = format_cost(m["output_price"] / 1_000_000) + "/tok"
        table.add_row(m["id"], inp_str, out_str)

    console.print(table)

    # Estadísticas
    source_api = sum(1 for m in models if m["source"] == "api")
    source_fb = sum(1 for m in models if m["source"] == "fallback")
    parts = []
    if source_api:
        parts.append(f"{source_api} de API")
    if source_fb:
        parts.append(f"{source_fb} de fallback local")
    console.print(f"\n[dim]{len(models)} modelos mostrados ({', '.join(parts)})[/dim]")
    if args.search:
        console.print(f"[dim]Búsqueda: {args.search}[/dim]")

    if args.limit and len(models) > args.limit:
        console.print(f"[yellow]⚠️ Mostrando {args.limit} de {len(models)} modelos. Usa --search para filtrar.[/yellow]")


def cmd_ab(args):
    """Comparación A/B: ejecuta 2 configs sobre el mismo input."""
    import os
    api_key = os.environ.get("OPENROUTER_API_KEY", "")
    if not api_key:
        console.print("[red]OPENROUTER_API_KEY no configurada[/red]")
        return

    from treval.eval import LLMEvaluator
    from openai import OpenAI

    # Mostrar qué se va a comparar
    console.print(f"[bold]🧪 Comparación A/B[/bold]")
    console.print(f"  Input: [dim]{args.input[:100]}[/dim]")
    console.print(f"  A: {args.model_a} (temp={args.temp_a})")
    console.print(f"  B: {args.model_b} (temp={args.temp_b})")
    console.print()

    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=api_key,
                    default_headers={"HTTP-Referer": "https://treval.dev", "X-Title": "treval-ab"})
    evaluator = LLMEvaluator(name="ab", criteria="correctness",
                             model="deepseek/deepseek-v4-flash")

    results = []
    for label, model, temp in [("A", args.model_a, args.temp_a),
                                 ("B", args.model_b, args.temp_b)]:
        console.print(f"[bold]Ejecutando {label}...[/bold]")
        import time
        start = time.perf_counter()
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": args.input}],
                temperature=temp,
                max_tokens=500,
            )
            output = response.choices[0].message.content or ""
            duration = (time.perf_counter() - start) * 1000
            usage = getattr(response, "usage", None)
            tokens = (usage.total_tokens if usage else 0) if hasattr(usage, "total_tokens") else 0
            score, reason = evaluator._llm_judge("correctness", args.input, output)
            results.append({
                "label": label,
                "model": model,
                "temp": temp,
                "output": output,
                "duration_ms": duration,
                "tokens": tokens,
                "score": score,
                "reason": reason,
            })
        except Exception as e:
            console.print(f"[red]Error en {label}: {e}[/red]")
            return

    # Mostrar comparación
    from rich.table import Table
    table = Table(title="Comparación A/B")
    table.add_column("", style="bold")
    for r in results:
        table.add_column(f"{r['label']} — {r['model'].split('/')[-1][:20]}", style="bold")

    table.add_row("Output",
                  results[0]["output"][:300] if len(results) > 0 else "-",
                  results[1]["output"][:300] if len(results) > 1 else "-")
    table.add_row("Duración",
                  f"{results[0]['duration_ms']:.0f}ms" if len(results) > 0 else "-",
                  f"{results[1]['duration_ms']:.0f}ms" if len(results) > 1 else "-")
    table.add_row("Tokens",
                  str(results[0].get("tokens", 0)) if len(results) > 0 else "-",
                  str(results[1].get("tokens", 0)) if len(results) > 1 else "-")

    score_a = results[0].get("score", 0) if len(results) > 0 else 0
    score_b = results[1].get("score", 0) if len(results) > 1 else 0
    table.add_row("Score",
                  f"{score_a:.2f}" if len(results) > 0 else "-",
                  f"{score_b:.2f}" if len(results) > 1 else "-")

    console.print(table)
    if score_a > score_b:
        console.print(f"\n[green]🏆 Ganador: A ({results[0]['model']}) con {score_a:.2f} vs {score_b:.2f}[/green]")
    elif score_b > score_a:
        console.print(f"\n[green]🏆 Ganador: B ({results[1]['model']}) con {score_b:.2f} vs {score_a:.2f}[/green]")
    else:
        console.print("\n[dim]Empate técnico[/dim]")


def main():
    parser = argparse.ArgumentParser(
        prog="treval",
        description="Traza, evalúa y mejora agentes de IA desde la terminal.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # treval spans
    p_spans = sub.add_parser("spans", help="Lista los spans recientes")
    p_spans.add_argument("-t", "--type", help="Filtrar por tipo (TOOL, AGENT, OPERATION)")
    p_spans.add_argument("-l", "--limit", type=int, default=20, help="Número de spans (default: 20)")
    p_spans.set_defaults(func=cmd_spans)

    # treval span <id>
    p_span = sub.add_parser("span", help="Detalle de un span")
    p_span.add_argument("span_id", type=int, help="ID del span")
    p_span.set_defaults(func=cmd_span_detail)

    # treval count
    sub.add_parser("count", help="Número total de spans").set_defaults(func=cmd_count)

    # treval clear
    sub.add_parser("clear", help="Borra todos los spans").set_defaults(func=cmd_clear)

    # treval eval
    p_eval = sub.add_parser("eval", help="Evalúa spans con LLM-as-judge")
    p_eval.add_argument("-c", "--criteria", default="correctness",
                        help="Criterio de evaluación (correctness, conciseness, helpfulness)")
    p_eval.add_argument("-t", "--type", help="Tipo de span a evaluar (TOOL, OPERATION, LLM)")
    p_eval.add_argument("-l", "--limit", type=int, default=10)
    p_eval.set_defaults(func=cmd_eval)

    # treval evals
    sub.add_parser("evals", help="Lista resultados de evaluaciones").set_defaults(func=cmd_evals)

    # treval export otlp
    p_export = sub.add_parser("export", help="Exporta spans a OTEL/OTLP")
    p_export.add_argument("--endpoint", default=None,
                          help="OTLP endpoint (ej: http://localhost:4317)")
    p_export.add_argument("--console", action="store_true",
                          help="Exportar a consola (stdout)")
    p_export.add_argument("-l", "--limit", type=int, default=1000)
    p_export.set_defaults(func=cmd_export)

    # treval test run
    p_test = sub.add_parser("test", help="Ejecuta tests para agentes")
    p_test_sub = p_test.add_subparsers(dest="test_subcommand", required=True)
    p_test_run = p_test_sub.add_parser("run", help="Ejecuta un archivo de test")
    p_test_run.add_argument("file", help="Archivo .py con la suite de tests")
    p_test_run.set_defaults(func=cmd_test_run)

    # treval replay <span_id>
    p_replay = sub.add_parser("replay", help="Re-ejecuta un span modificando parámetros")
    p_replay.add_argument("span_id", type=int, help="ID del span a re-ejecutar")
    p_replay.add_argument("--input", help="Nuevo input (opcional)")
    p_replay.add_argument("--model", help="Modelo a usar (default: el original)")
    p_replay.add_argument("--temperature", type=float, default=None, help="Temperatura (default: 0.1)")
    p_replay.set_defaults(func=cmd_replay)

    # treval dashboard
    p_dash = sub.add_parser("dashboard", help="Arranca el dashboard web local")
    p_dash.add_argument("--port", type=int, default=8080, help="Puerto (default: 8080)")
    p_dash.add_argument("--no-open", action="store_true", help="No abrir navegador")
    p_dash.add_argument("--export", type=str, default=None,
                        help="Exporta a archivo HTML estático (ej: dashboard.html)")
    p_dash.set_defaults(func=cmd_dashboard)

    # treval metrics
    sub.add_parser("metrics", help="Muestra métricas agregadas de los spans").set_defaults(func=cmd_metrics)

    # treval compare
    p_compare = sub.add_parser("compare", help="Compara N modelos × M ejecuciones con stats y costes")
    p_compare.add_argument("-p", "--prompt", help="Prompt para la comparación")
    p_compare.add_argument("-m", "--models", default="deepseek/deepseek-v4-flash,deepseek/deepseek-v4-pro",
                           help="Modelos separados por comas (default: flash,pro)")
    p_compare.add_argument("-r", "--runs", type=int, default=3,
                           help="Número de ejecuciones por modelo (default: 3)")
    p_compare.add_argument("-c", "--criteria", default="correctness",
                           help="Criterio de evaluación (correctness, conciseness, helpfulness)")
    p_compare.add_argument("-o", "--export", help="Exportar reporte HTML a archivo (ej: compare.html)")
    p_compare.add_argument("-a", "--agent", help="Comando del agente a comparar (modo agente)")
    p_compare.set_defaults(func=cmd_compare)

    # treval prices
    p_prices = sub.add_parser("prices", help="Muestra precios de modelos desde OpenRouter API")
    p_prices.add_argument("-s", "--search", help="Filtrar modelos por nombre")
    p_prices.add_argument("-l", "--limit", type=int, default=0, help="Limitar número de resultados")
    p_prices.set_defaults(func=cmd_prices)

    # treval init
    p_init = sub.add_parser("init", help="Crea un proyecto agente con treval preconfigurado")
    p_init.add_argument("path", nargs="?", default="./mi-agente",
                        help="Ruta del proyecto (default: ./mi-agente)")
    p_init.set_defaults(func=cmd_init)

    # treval ab
    p_ab = sub.add_parser("ab", help="Comparación A/B entre 2 modelos/configs")
    p_ab.add_argument("input", help="Input para la comparación")
    p_ab.add_argument("--model-a", default="deepseek/deepseek-v4-flash", help="Modelo A (default: flash)")
    p_ab.add_argument("--model-b", default="deepseek/deepseek-v4-pro", help="Modelo B (default: pro)")
    p_ab.add_argument("--temp-a", type=float, default=0.1, help="Temperatura A (default: 0.1)")
    p_ab.add_argument("--temp-b", type=float, default=0.7, help="Temperatura B (default: 0.7)")
    p_ab.set_defaults(func=cmd_ab)

    # treval gateway
    p_gw = sub.add_parser("gateway", help="Arranca el proxy gateway para interceptar tráfico LLM")
    p_gw.add_argument("--port", type=int, default=9090, help="Puerto (default: 9090)")
    p_gw.add_argument("--host", default="127.0.0.1", help="Host (default: 127.0.0.1)")
    p_gw.add_argument("--upstream", choices=["openrouter", "openai"], default="openrouter",
                      help="API upstream (default: openrouter)")
    p_gw.set_defaults(func=cmd_gateway)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()