"""Tests para el agente ReAct usando LLM-as-judge."""
from treval.testing import case, TestSuite

suite = TestSuite(name="WeatherTests")


@case(suite,
      input="que clima hace en Madrid?",
      criteria="La respuesta debe mencionar el clima de Madrid")
def test_madrid(response: str) -> None:
    assert "Madrid" in response
    assert "28" in response or "soleado" in response


@case(suite,
      input="cuanto es 2+2?",
      criteria="La respuesta debe ser correcta matematicamente")
def test_math(response: str) -> None:
    assert "4" in response or "cuatro" in response