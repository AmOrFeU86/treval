"""Evaluaciones LLM-as-judge para spans de treval.

Uso:
    import treval
    evaluator = treval.LLMEvaluator(model="deepseek/deepseek-v4-flash",
                                    criteria="La respuesta debe ser correcta")
    scores = evaluator.evaluate(spans)
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any


def _parse_judge_json(text: str) -> tuple[float, str]:
    """Extrae score y reason del JSON de un juez LLM, tolerando JSON mal formado.

    Estrategias en orden:
    1. json.loads directo (caso ideal)
    2. json.loads tras limpiar markdown/backticks
    3. Regex para extraer score + reason de JSON suelto
    4. Regex para extraer solo el score
    """
    text = text.strip()

    # Estrategia 1: JSON directo
    try:
        data = json.loads(text)
        score = _clamp_score(data.get("score", 0.5))
        reason = str(data.get("reason", ""))
        return score, reason
    except json.JSONDecodeError:
        pass

    # Estrategia 2: Limpiar markdown y reintentar
    cleaned = text
    # Quitar bloques ```json ... ``` o ``` ... ```
    m = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", cleaned, re.DOTALL)
    if m:
        cleaned = m.group(1).strip()
    # Quitar markdown inline
    cleaned = re.sub(r"^[#>*\-]\s*", "", cleaned, flags=re.MULTILINE).strip()
    # Quitar texto antes del primer { y después del último }
    brace_start = cleaned.find("{")
    brace_end = cleaned.rfind("}")
    if brace_start != -1 and brace_end != -1 and brace_end > brace_start:
        cleaned = cleaned[brace_start : brace_end + 1]
    try:
        data = json.loads(cleaned)
        return _clamp_score(data.get("score", 0.5)), str(data.get("reason", ""))
    except json.JSONDecodeError:
        pass

    # Estrategia 3: Regex para extraer score de JSON parcialmente roto
    score_match = re.search(r'"?score"?\s*:\s*([0-9]*\.?[0-9]+)', text)
    reason_match = re.search(r'"?reason"?\s*:\s*"(.+?)(?:"|\n|$)', text, re.DOTALL)
    if score_match:
        score = _clamp_score(float(score_match.group(1)))
        reason = reason_match.group(1).strip() if reason_match else "JSON mal formado, score extraído por regex"
        return score, reason

    # Estrategia 4: Buscar cualquier número en contexto de score
    score_match = re.search(r"([0-9]*\.?[0-9]+)", text)
    if score_match:
        score = _clamp_score(float(score_match.group(1)))
        return score, "Score estimado por patrón numérico"

    return 0.5, "No se pudo parsear la evaluación"


def _clamp_score(s: float) -> float:
    return max(0.0, min(1.0, float(s)))

from treval.db import SpanStore

EVAL_DB_PATH = Path.home() / ".treval" / "evals.db"


@dataclass
class EvalResult:
    span_id: int
    evaluator_name: str
    score: float  # 0.0 - 1.0
    reason: str = ""
    metadata: dict = field(default_factory=dict)
    created_at: str = ""


class EvalStore:
    """Almacén de resultados de evaluaciones en SQLite local."""

    _lock = threading.Lock()

    def __init__(self, db_path: str | Path | None = None):
        self._db_path = Path(db_path) if db_path else EVAL_DB_PATH
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._lock:
            conn = self._conn()
            conn.execute("""
                CREATE TABLE IF NOT EXISTS evaluations (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    span_id         INTEGER NOT NULL,
                    evaluator_name  TEXT NOT NULL,
                    score           REAL NOT NULL,
                    reason          TEXT,
                    metadata        TEXT,
                    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
                )
            """)
            conn.commit()
            conn.close()

    def save(self, result: EvalResult) -> int:
        with self._lock:
            conn = self._conn()
            cur = conn.execute(
                """INSERT INTO evaluations (span_id, evaluator_name, score, reason, metadata)
                   VALUES (?, ?, ?, ?, ?)""",
                (result.span_id, result.evaluator_name, result.score,
                 result.reason, json.dumps(result.metadata) if result.metadata else None),
            )
            conn.commit()
            conn.close()
            return cur.lastrowid

    def list(self, limit: int = 50) -> list[dict]:
        conn = self._conn()
        rows = conn.execute(
            """SELECT e.*, NULL as span_name, NULL as span_type
               FROM evaluations e
               ORDER BY e.id DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        conn.close()
        # Intentar enriquecer con nombre del span si la BD de spans es accesible
        try:
            from treval.db import SpanStore, DB_PATH
            sconn = sqlite3.connect(str(DB_PATH))
            sconn.row_factory = sqlite3.Row
            for row in rows:
                srow = sconn.execute("SELECT name, type FROM spans WHERE id = ?",
                                     (row["span_id"],)).fetchone()
                if srow:
                    row["span_name"] = srow["name"]
                    row["span_type"] = srow["type"]
            sconn.close()
        except Exception:
            pass
        return [dict(r) for r in rows]

    def get_stats(self) -> dict:
        conn = self._conn()
        row = conn.execute(
            "SELECT COUNT(*) as count, AVG(score) as avg_score, MIN(score) as min, MAX(score) as max FROM evaluations"
        ).fetchone()
        conn.close()
        return dict(row) if row else {"count": 0, "avg_score": None, "min": None, "max": None}

    def clear(self) -> None:
        with self._lock:
            conn = self._conn()
            conn.execute("DELETE FROM evaluations")
            conn.commit()
            conn.close()


class LLMEvaluator:
    """Evalúa spans usando un LLM como juez.

    Criterios comunes:
    - "correctness": La respuesta es correcta respecto a la pregunta
    - "conciseness": La respuesta es concisa sin información irrelevante
    - "helpfulness": La respuesta es útil para el usuario
    - "groundedness": La respuesta usa las tools correctamente
    """

    def __init__(self, name: str = "", criteria: str = "correctness",
                 api_key: str | None = None, base_url: str | None = None,
                 model: str = "deepseek/deepseek-v4-flash"):
        self.name = name or criteria
        self.criteria = criteria
        self.api_key = api_key or os.environ.get("OPENROUTER_API_KEY", "")
        self.base_url = base_url or "https://openrouter.ai/api/v1"
        self.model = model

    def evaluate(self, spans: list[dict]) -> list[EvalResult]:
        """Evalúa una lista de spans devolviendo resultados.

        Para spans TOOL y OPERATION, evalúa el output contra el input.
        Para spans LLM, evalúa la respuesta.
        """
        results = []
        for span in spans:
            result = self._evaluate_one(span)
            if result:
                results.append(result)
        return results

    def evaluate_span(self, span: dict) -> EvalResult | None:
        """Evalúa un único span."""
        return self._evaluate_one(span)

    def _evaluate_one(self, span: dict) -> EvalResult | None:
        if not span.get("input") or not span.get("output"):
            return None

        score, reason = self._llm_judge(
            criteria=self.criteria,
            input_text=span["input"],
            output_text=span["output"],
        )
        return EvalResult(
            span_id=span["id"],
            evaluator_name=self.name,
            score=score,
            reason=reason,
            metadata={"criteria": self.criteria, "model": self.model, "span_type": span.get("type")},
            created_at=datetime.now().isoformat(),
        )

    def _llm_judge(self, criteria: str, input_text: str, output_text: str) -> tuple[float, str]:
        """Llama al LLM para juzgar un output según el criterio."""
        prompt = f"""Eres un evaluador justo y preciso. Evalúa la siguiente respuesta según el criterio especificado.

CRITERIO: {criteria}

INPUT (pregunta/instrucción):
{input_text[:1500]}

OUTPUT (respuesta a evaluar):
{output_text[:1500]}

Devuelve tu evaluación ÚNICAMENTE en el siguiente formato JSON (sin markdown, sin explicación extra):
{{"score": <número entre 0.0 y 1.0>, "reason": "<explicación breve de 1-2 frases>"}}"""
        try:
            from openai import OpenAI
            client = OpenAI(
                base_url=self.base_url,
                api_key=self.api_key,
            )
            response = client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0,
                max_tokens=200,
            )
            text = response.choices[0].message.content or "{}"
            return _parse_judge_json(text)
        except Exception as e:
            return 0.5, f"Error evaluando: {e}"


# Evaluadores predefinidos
CORRECTNESS_EVALUATOR = LLMEvaluator(
    name="correctness",
    criteria="""La respuesta es correcta, precisa y factual.
Puntúa alto (0.8-1.0) si la respuesta responde correctamente a la pregunta.
Puntúa bajo (0.0-0.3) si la respuesta contiene información incorrecta o no responde.""",
)

CONCISENESS_EVALUATOR = LLMEvaluator(
    name="conciseness",
    criteria="""La respuesta es concisa y directa, sin información irrelevante.
Puntúa alto si es breve y va al grano.
Puntúa bajo si es verbosa o contiene detalles innecesarios.""",
)

HELPFULNESS_EVALUATOR = LLMEvaluator(
    name="helpfulness",
    criteria="""La respuesta es útil, accionable y resuelve la necesidad del usuario.
Puntúa alto si el usuario puede actuar basándose en la respuesta.
Puntúa bajo si es genérica, vaga o no resuelve el problema.""",
)